# TokenRing

Objetivos
- Utilizar programação multithreading;
- Praticar técnicas de sincronização de processos;
- Aprofundar conceitos de redes de computadores;
- Aprender sobre a utilização do protocolo UDP para troca de mensagens;
- Explorar o conceito de interoperabilidade.
